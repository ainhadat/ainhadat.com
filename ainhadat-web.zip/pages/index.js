import { useMemo, useState } from "react";

const LOCATIONS = [
  { code: "hn", name: "Hà Nội", districts: [
    { code: "hn-ba_dinh", name: "Ba Đình", wards: ["Phúc Xá", "Trúc Bạch"] },
    { code: "hn-cau_giay", name: "Cầu Giấy", wards: ["Dịch Vọng", "Dịch Vọng Hậu"] }
  ]},
  { code: "dn", name: "Đà Nẵng", districts: [
    { code: "dn-hai_chau", name: "Hải Châu", wards: ["Thạch Thang", "Hải Châu I"] }
  ]}
];

const MOCK_PROPERTIES = [
  { id:1, title:"Nhà phố 4 tầng, hướng Đông, mặt tiền 5m", province:"Hà Nội", district:"Cầu Giấy", ward:"Dịch Vọng", price:4200000000, area:80, type:"Nhà phố", direction:"Đông", amenities:["Gần trường học","Camera an ninh"], description:"Nhà thiết kế hiện đại, thuận tiện giao thông." },
  { id:2, title:"Đất nền 120m2 - Hướng Nam, gần đường lớn", province:"Đà Nẵng", district:"Hải Châu", ward:"Thạch Thang", price:2500000000, area:120, type:"Đất nền", direction:"Nam", amenities:["Gần chợ"], description:"Vị trí đẹp, sổ đỏ chính chủ." },
  { id:3, title:"Căn hộ 2PN, view city, tiện ích đầy đủ", province:"Hà Nội", district:"Ba Đình", ward:"Phúc Xá", price:1800000000, area:65, type:"Chung cư", direction:"Tây", amenities:["Gần bệnh viện","Hồ bơi"], description:"Căn hộ mới, thuận tiện cho gia đình nhỏ." }
];

function formatPriceShort(n){
  if(n>=1000000000){
    const val = Math.round(n/100000000)/10; // e.g. 2.5
    if(val >= 10) return Math.round(val) + " tỷ";
    return val + " tỷ";
  }
  if(n>=1000000){
    const val = Math.round(n/1000000);
    return val + " triệu";
  }
  return n + " ₫";
}

export default function Home(){
  const [keyword, setKeyword] = useState("");
  const [province, setProvince] = useState("");
  const [district, setDistrict] = useState("");
  const [ward, setWard] = useState("");
  const [priceMax, setPriceMax] = useState(100000000000);
  const [areaMax, setAreaMax] = useState(1000);
  const [direction, setDirection] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  const districts = useMemo(()=> {
    const p = LOCATIONS.find(l=> l.name === province);
    return p ? p.districts : [];
  }, [province]);

  const wards = useMemo(()=> {
    const d = districts.find(dd => dd.name === district);
    return d ? d.wards : [];
  }, [districts, district]);

  const filtered = useMemo(()=>{
    return MOCK_PROPERTIES.filter(p=>{
      if(keyword && !(`${p.title} ${p.description}`.toLowerCase().includes(keyword.toLowerCase()))) return false;
      if(province && p.province !== province) return false;
      if(district && p.district !== district) return false;
      if(ward && p.ward !== ward) return false;
      if(p.price > priceMax) return false;
      if(p.area > areaMax) return false;
      if(direction && p.direction !== direction) return false;
      if(typeFilter && p.type !== typeFilter) return false;
      return true;
    });
  }, [keyword, province, district, ward, priceMax, areaMax, direction, typeFilter]);

  return (
    <div className="min-h-screen">
      <header className="max-w-7xl mx-auto py-6 px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#4f46e5] to-[#06b6d4] flex items-center justify-center shadow-glow">
            <span className="font-bold">AI</span>
          </div>
          <div>
            <div className="font-extrabold text-xl text-white">AI NHÀ ĐẤT</div>
            <div className="text-xs text-gray-300">AI phân tích – Chọn đúng nhà bạn cần</div>
          </div>
        </div>
        <nav className="flex gap-4 items-center">
          <button className="px-4 py-2 rounded-lg bg-transparent border border-gray-700 hover:bg-white/5">Đăng tin</button>
          <button className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#4f46e5] to-[#06b6d4] shadow-md">Đăng nhập</button>
        </nav>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-4">
        <section className="grid grid-cols-12 gap-6">
          <aside className="col-span-4">
            <div className="rounded-2xl p-5 bg-white/3 border border-white/6">
              <h3 className="font-bold mb-3">Bộ lọc</h3>

              <label className="text-sm text-gray-300">Từ khóa</label>
              <input value={keyword} onChange={e=>setKeyword(e.target.value)} placeholder="Ví dụ: nhà 2 tầng Cầu Giấy" className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2"/>

              <label className="text-sm text-gray-300">Tỉnh / Thành phố</label>
              <select value={province} onChange={e=>{setProvince(e.target.value); setDistrict(''); setWard('');}} className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2">
                <option value="">Tất cả</option>
                {LOCATIONS.map(l=> <option key={l.code} value={l.name}>{l.name}</option>)}
              </select>

              <label className="text-sm text-gray-300">Quận / Huyện</label>
              <select value={district} onChange={e=>{setDistrict(e.target.value); setWard('');}} className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2">
                <option value="">Tất cả</option>
                {districts.map(d=> <option key={d.code} value={d.name}>{d.name}</option>)}
              </select>

              <label className="text-sm text-gray-300">Phường / Xã</label>
              <select value={ward} onChange={e=>setWard(e.target.value)} className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2">
                <option value="">Tất cả</option>
                {wards.map(w=> <option key={w} value={w}>{w}</option>)}
              </select>

              <label className="text-sm text-gray-300">Giá tối đa</label>
              <select value={priceMax} onChange={e=>setPriceMax(Number(e.target.value))} className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2">
                <option value={100000000000}>Không giới hạn</option>
                <option value={500000000}>500 triệu</option>
                <option value={1000000000}>1 tỷ</option>
                <option value={2000000000}>2 tỷ</option>
                <option value={5000000000}>5 tỷ</option>
                <option value={10000000000}>10 tỷ</option>
              </select>

              <label className="text-sm text-gray-300">Diện tích tối đa (m²)</label>
              <input type="number" value={areaMax} onChange={e=>setAreaMax(Number(e.target.value))} className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2"/>

              <label className="text-sm text-gray-300">Hướng</label>
              <select value={direction} onChange={e=>setDirection(e.target.value)} className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2">
                <option value="">Bất kỳ</option>
                <option>Đông</option>
                <option>Tây</option>
                <option>Nam</option>
                <option>Bắc</option>
              </select>

              <label className="text-sm text-gray-300">Loại hình</label>
              <select value={typeFilter} onChange={e=>setTypeFilter(e.target.value)} className="w-full mt-1 mb-3 bg-transparent border border-gray-700 rounded-md px-3 py-2">
                <option value="">Tất cả</option>
                <option>Nhà phố</option>
                <option>Đất nền</option>
                <option>Chung cư</option>
                <option>Shophouse</option>
              </select>

              <div className="mt-4 flex gap-2">
                <button onClick={()=>{ setKeyword(''); setProvince(''); setDistrict(''); setWard(''); setPriceMax(100000000000); setAreaMax(1000); setDirection(''); setTypeFilter(''); }} className="flex-1 px-4 py-2 rounded-md border border-white/6">Reset</button>
                <button onClick={()=>window.scrollTo({top:0, behavior:'smooth'})} className="flex-1 px-4 py-2 rounded-md bg-gradient-to-r from-[#4f46e5] to-[#06b6d4]">Áp dụng</button>
              </div>
            </div>

            <div className="mt-4 rounded-xl p-4 bg-white/4 border border-white/6">
              <div className="font-semibold">Gợi ý từ AI</div>
              <div className="text-sm text-gray-300 mt-2">Ví dụ: “Nhà 2 tỷ, 3 phòng ngủ, gần trường học” — AI sẽ lọc và gợi ý.</div>
            </div>
          </aside>

          <div className="col-span-8">
            <div className="rounded-2xl p-6 bg-gradient-to-br from-white/3 via-white/6 to-white/2 backdrop-blur-md border border-white/5">
              <h1 className="text-2xl font-bold mb-2">Danh sách bất động sản</h1>
              <p className="text-gray-300 mb-4">Kết quả tìm kiếm (dữ liệu demo)</p>

              <div className="grid grid-cols-1 gap-4">
                {filtered.map(p=> (
                  <div key={p.id} className="rounded-xl bg-white/4 p-4 border border-white/6 flex gap-4">
                    <div className="w-36 h-24 bg-gray-700 rounded-md flex items-center justify-center">Ảnh</div>
                    <div className="flex-1">
                      <div className="font-semibold text-white">{p.title}</div>
                      <div className="text-xs text-gray-300">{p.province} • {p.district} • {p.ward}</div>
                      <div className="mt-2 flex items-center justify-between">
                        <div className="text-lg font-bold text-white">{formatPriceShort(p.price)}</div>
                        <div className="text-sm text-gray-300">{p.area} m² • {p.type}</div>
                      </div>
                      <div className="mt-3 flex gap-2">
                        <button className="px-3 py-1 rounded-md bg-white/6">Xem chi tiết</button>
                        <button className="px-3 py-1 rounded-md border border-white/6">So sánh</button>
                      </div>
                    </div>
                  </div>
                ))}
                {filtered.length === 0 && <div className="text-gray-300 p-6">Không tìm thấy kết quả</div>}
              </div>
            </div>
          </div>
        </section>
      </main>

      <div className="fixed right-6 bottom-6 z-40">
        <div className="w-14 h-14 rounded-full bg-gradient-to-r from-[#4f46e5] to-[#06b6d4] flex items-center justify-center shadow-lg cursor-pointer">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="white"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M21 12c0 4.418-4.03 8-9 8-1.5 0-2.915-.274-4.16-.77L3 20l1.77-4.84C3.82 13.945 3 12.06 3 10c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        </div>
      </div>
    </div>
  )
}
